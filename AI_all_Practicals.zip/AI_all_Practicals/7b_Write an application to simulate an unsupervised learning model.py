import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import scipy.cluster.hierarchy as shc
from sklearn.cluster import AgglomerativeClustering

# Load customer data with encoding parameter to avoid Unicode errors
customer_data = pd.read_csv(r'C:\Users\PRATHAM\Downloads\AI Practicals Part-2\mall_cust.csv', encoding='utf-8')

# If utf-8 doesn't work, you can try using 'ISO-8859-1' or 'utf-8-sig'
# customer_data = pd.read_csv(r'C:\Users\PRATHAM\Downloads\AI Practicals Part-2\mall_cust.csv', encoding='ISO-8859-1')
# customer_data = pd.read_csv(r'C:\Users\PRATHAM\Downloads\AI Practicals Part-2\mall_cust.csv', encoding='utf-8-sig')

# Display the shape and the first few rows of the dataset
print("Dataset shape:", customer_data.shape)
print(customer_data.head())

# Select the relevant features for clustering
data = customer_data.iloc[:, 3:5].values

# Create a dendrogram to visualize the hierarchical clustering
plt.figure(figsize=(10, 7))
plt.title("Customer Dendrograms")
dend = shc.dendrogram(shc.linkage(data, method='ward'))

# Perform Agglomerative Clustering without the 'affinity' argument
cluster = AgglomerativeClustering(n_clusters=5, linkage='ward')  # Removed affinity
labels = cluster.fit_predict(data)

# Plot the clustered data
plt.figure(figsize=(10, 7))
plt.scatter(data[:, 0], data[:, 1], c=labels, cmap='rainbow')
plt.title("Clusters of Customers")
plt.xlabel("Feature 1")  # Change according to your dataset
plt.ylabel("Feature 2")  # Change according to your dataset
plt.show()



#IN CMD

#1 Install mall_cust.csv from : https://gist.github.com/pravalliyaram/5c05f43d2351249927b8a3f3cc3e5ecf
#2 set path as per own pc paths
