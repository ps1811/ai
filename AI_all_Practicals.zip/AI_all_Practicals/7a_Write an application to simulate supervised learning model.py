import numpy as np
import matplotlib.pyplot as plt
import pandas as pd
import seaborn as sns
from sklearn.linear_model import LogisticRegression
from sklearn import datasets
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import confusion_matrix

# Load the iris dataset
dataset = datasets.load_iris()
X = dataset.data[:, [0, 1, 2, 3]]
y = dataset.target

# Split the dataset into training and testing sets
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.25, random_state=0)

# Standardize the features
sc = StandardScaler()
X_train = sc.fit_transform(X_train)
X_test = sc.transform(X_test)  # Use transform here instead of fit_transform

# Create and train the logistic regression classifier
classifier = LogisticRegression(random_state=0, solver='lbfgs')  # Removed multi_class
classifier.fit(X_train, y_train)

# Make predictions
y_pred = classifier.predict(X_test)
probs_y = classifier.predict_proba(X_test)

# Create confusion matrix
cm = confusion_matrix(y_test, y_pred)
print(cm)

# Plot the confusion matrix
plt.figure(figsize=(8, 6))
ax = plt.axes()
df_cm = pd.DataFrame(cm, index=range(3), columns=range(3))  # Update to match the iris dataset's classes
sns.heatmap(df_cm, annot=True, fmt='d', cmap='Blues', ax=ax)
ax.set_title('Confusion Matrix')
ax.set_xlabel('Predicted Labels')
ax.set_ylabel('True Labels')
plt.show()


#IN CMD
#1 py -m pip install pandas
#2 py -m pip install seaborn
#3 py -m pip install scikit-learn

