#Add this command in cmd first : py -m pip install python-aiml

import aiml

def main():
    # Create an AIML kernel
    kernel = aiml.Kernel()

    # Load the AIML knowledge base
    kernel.learn("flu.aiml")

    print("Welcome to the flu diag center")

    while True:
        user_input = input("You: ").strip().lower()
        if user_input == 'exit':
            print("Goodbye!")
            break

        response = kernel.respond(user_input)
        print("Expert System: " + response)

if __name__ == "__main__":
    main()

#write below things to get output
#1 fever cough (output milega then 2 wala)
#2 fever
#3 cough
#4 exit