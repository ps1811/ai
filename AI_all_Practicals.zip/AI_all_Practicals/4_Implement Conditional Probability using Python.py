def conditional():
    pass_stats = 0.15
    pass_coding_with_stats = 0.60
    pass_coding_without_stats = 0.40

    # Calculate the probability that the applicant passes both
    prob_both = pass_stats * pass_coding_with_stats
    print("The probability that the applicant passes both is", round(prob_both, 3))

    # Calculate the probability that the applicant passes only coding
    prob_coding = prob_both + ((1 - pass_stats) * pass_coding_without_stats)
    print("Probability that he/she passes only coding is", round(prob_coding, 3))

    # Calculate the conditional probability
    status_given_coding = prob_both / prob_coding
    print("Conditional Probability is", round(status_given_coding, 3))

print("Pratham Sharma")
conditional()
