import numpy as np
from sklearn.datasets import make_classification
import matplotlib.pyplot as plt

# Generate a synthetic classification dataset
x, y = make_classification(
    n_samples=1000,
    n_features=2,
    n_informative=2,
    n_redundant=0,
    n_clusters_per_class=1,
    random_state=4
)

# Plotting the classes
for class_value in range(2):
    row_ix = np.where(y == class_value)
    plt.scatter(x[row_ix, 0], x[row_ix, 1], label=f'Class {class_value}')

# Adding title and labels
plt.title('Scatter Plot of Synthetic Classification Dataset')
plt.xlabel('Feature 1')
plt.ylabel('Feature 2')
plt.legend()
plt.show()
