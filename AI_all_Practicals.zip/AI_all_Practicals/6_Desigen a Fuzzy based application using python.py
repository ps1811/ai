import numpy as np
import skfuzzy as fuzz
from skfuzzy import control as ctrl

# Define the input and output variables
quality = ctrl.Antecedent(np.arange(0, 11, 1), 'quality')
service = ctrl.Antecedent(np.arange(0, 11, 1), 'service')
tip = ctrl.Consequent(np.arange(0, 26, 1), 'tip')

# Automatically create fuzzy membership functions
quality.automf(3)
service.automf(3)

# Define the tip membership functions
tip['low'] = fuzz.trimf(tip.universe, [0, 0, 13])
tip['medium'] = fuzz.trimf(tip.universe, [0, 13, 25])
tip['high'] = fuzz.trimf(tip.universe, [13, 25, 25])

# View the membership functions (optional)
quality.view()
service.view()
tip.view()

# Define the fuzzy rules
rule1 = ctrl.Rule(quality['poor'] | service['poor'], tip['low'])
rule2 = ctrl.Rule(service['average'], tip['medium'])
rule3 = ctrl.Rule(service['good'] | quality['good'], tip['high'])

# Optionally view the rules (uncomment to use)
# rule1.view()

# Create the control system
tipping_ctrl = ctrl.ControlSystem([rule1, rule2, rule3])
tipping = ctrl.ControlSystemSimulation(tipping_ctrl)

# Input values
tipping.input['quality'] = 6.5
tipping.input['service'] = 9.8

# Compute the output
tipping.compute()

# Output the result
print("Tip output:", tipping.output['tip'])

# View the results (optional)
tip.view(sim=tipping)



#IN CMD

#1 py -m pip install numpy
#2 py -m pip install scikit-fuzzy
#3 py -m pip install scipy
#4 py -m pip install --upgrade pip setuptools wheel numpy scipy scikit-fuzzy
#5 py -m pip install packaging
#6 py -m pip install networkx
#7 py -m pip install matplotlib


