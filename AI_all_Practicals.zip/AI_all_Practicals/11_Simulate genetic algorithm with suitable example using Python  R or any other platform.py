import random

Population_size = 100
Genes = '''abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ123456780,.:;_!@#$%^&*()?{}[]'''
Target = "I love GeeksforGeeks"

class Individual(object):
    def __init__(self, chromosome):
        self.chromosome = chromosome
        self.fitness = self.cal_fitness()

    @classmethod
    def mutated_genes(cls):
        global Genes
        gene = random.choice(Genes)
        return gene

    @classmethod
    def create_gnome(cls):
        global Target
        gnome_len = len(Target)
        return [cls.mutated_genes() for _ in range(gnome_len)]

    def mate(self, par2):
        child_chromosome = []
        for gp1, gp2 in zip(self.chromosome, par2.chromosome):
            prob = random.random()
            if prob < 0.45:
                child_chromosome.append(gp1)
            elif prob < 0.90:
                child_chromosome.append(gp2)
            else:
                child_chromosome.append(self.mutated_genes())  # Mutation rate
        return Individual(child_chromosome)

    def cal_fitness(self):
        global Target
        fitness = sum(1 for gs, gt in zip(self.chromosome, Target) if gs != gt)  # Incorrect characters
        return fitness

def main():
    global Population_size
    generation = 1
    found = False
    Population = []

    # Initialize population
    for _ in range(Population_size):
        gnome = Individual.create_gnome()
        Population.append(Individual(gnome))

    # Maximum generations to prevent infinite loop
    max_generations = 1000

    while not found and generation <= max_generations:
        Population = sorted(Population, key=lambda x: x.fitness)

        if Population[0].fitness == 0:  # Found the target string
            found = True
            break

        new_gen = []
        s = int((10 * Population_size) / 100)
        new_gen.extend(Population[:s])  # Elitism: keep the best 10%

        s = int((90 * Population_size) / 100)
        for _ in range(s):
            parent1 = random.choice(Population[:50])  # Select parents from the top 50 individuals
            parent2 = random.choice(Population[:50])
            child = parent1.mate(parent2)
            new_gen.append(child)

        Population = new_gen
        print("Generation: {} \tString: {}\tFitness: {}".format(generation, "".join(Population[0].chromosome), Population[0].fitness))
        generation += 1

    if found:
        print("Generation: {} \tString: {}\tFitness: {}".format(generation, "".join(Population[0].chromosome), Population[0].fitness))
    else:
        print(f"Target not found in {max_generations} generations.")

if __name__ == '__main__':
    main()
