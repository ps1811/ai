#First run this command in cmd : py -m pip install python-aiml

import aiml

# Create an AIML kernel
kernel = aiml.Kernel()

# Load the AIML file
kernel.learn("bot.aiml")

print("Bot: Hello! Type 'exit' to end the conversation.")

# Use a loop for user interactions
while True:
    user_input = input("You: ").strip()
    if user_input.lower() == "exit":
        print("Bot: Goodbye!")
        break
    bot_response = kernel.respond(user_input)
    print("Bot:", bot_response)

#output texts
#1 hello
#2 Tell me a joke
#3 what is the capital of turkey
# exit