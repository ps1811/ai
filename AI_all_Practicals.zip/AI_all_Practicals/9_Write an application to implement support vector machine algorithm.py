import numpy as np
import matplotlib.pyplot as plt
from sklearn import svm, datasets

# Load the iris dataset
iris = datasets.load_iris()
x = iris.data[:, :2]  # Use only the first two features
y = iris.target

# Create an SVM classifier with a linear kernel
svc = svm.SVC(kernel='linear', C=1, gamma='scale').fit(x, y)

# Define the limits for the mesh grid
x_min, x_max = x[:, 0].min() - 1, x[:, 0].max() + 1
y_min, y_max = x[:, 1].min() - 1, x[:, 1].max() + 1
h = (x_max - x_min) / 100  # Step size

# Create the mesh grid
xx, yy = np.meshgrid(np.arange(x_min, x_max, h), np.arange(y_min, y_max, h))

# Predict using the SVM model
z = svc.predict(np.c_[xx.ravel(), yy.ravel()])
z = z.reshape(xx.shape)

# Plotting
plt.figure(figsize=(10, 6))
plt.contourf(xx, yy, z, cmap=plt.cm.Paired, alpha=0.8)  # Filled contour plot
plt.scatter(x[:, 0], x[:, 1], c=y, cmap=plt.cm.Paired, edgecolors='k')  # Scatter plot
plt.xlabel('Sepal Length')
plt.ylabel('Sepal Width')
plt.xlim(xx.min(), xx.max())
plt.title('SVC with Linear Kernel')
plt.colorbar()  # Add a colorbar
plt.show()
